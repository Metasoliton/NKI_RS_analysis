#!/bin/bash
TR="2.010"
num_of_fMRI_scans="182"
FWHM="6"
total_smoothness="11"   		

mk dir ../Data/swusub_3mm
for VP in $inVPs
do
inDataEPI="/Volumes/Research/Rockland_R1/Data/swusub/swusub-${VP}_ses-NFB3_task-DMNTRACKINGTRAIN_bold.nii"
EPI_fileName=$(basename ${inDataEPI})
EPI_dirName=$(dirname ${inDataEPI})
flirt -in ${EPI_dirName}/${EPI_fileName}  -ref ${EPI_dirName}/${EPI_fileName}  -out ../Data/swusub_3mm/swusub-${VP}_3mm      -applyisoxfm 3
done

for VP in $inVPs
do
    bash ./do_prep_v3.sh ${VP} ${FWHM} ${TR}    # prepare & preprocess data & also make an MNI-registered mask for each participant, to be used for the ECM analysis
    bash ./process_sub.sh ${VP} ${TR}           # perform ECM analysis 
done


#   # 2nd-level analysis: group statistics - mean DMN

## TEST PATHO vs CTRL in DMN mask
DMN_msk="../Data/utils/IC_0003_DMN_thr3_seedROI_3mm"
vvinidi   -in  ${DMN_msk}.nii.gz     -out ${DMN_msk}.v      -repn s16bit
vvinidi   -in  ../Data/utils/ICBM_BRAIN_MNI_3mm_4FSL.nii       -out ../Data/utils/tmp.v  -repn s16bit
valign3d -in ../Data/utils/tmp.v -ref /usr/share/lipsia/mni.v -trans ../Data/utils/tmp_trans.nii -prealign  true -transform VersorRigid
vdotrans3d -in ${DMN_msk}.v -ref /usr/share/lipsia/mni.v -trans ../Data/utils/tmp_trans.nii -out ../Data/utils/DMN_msk_3mm.v -res 3 
vbinarize -in ../Data/utils/DMN_msk_3mm.v -out ../Data/utils/DMN_msk_3mm_bin.v

bash dfn_ctrl.sh ; for sub in ${CTRL_subs}; do mv  ../Group_Stat/ECM/gauss/gauss_${sub}_ecm_pos.v ../Group_Stat/ECM/ctrl/gauss_${sub}_ecm_pos.v; done 
bash dfn_path.sh ; for sub in ${PATH_subs}; do mv  ../Group_Stat/ECM/gauss/gauss_${sub}_ecm_pos.v ../Group_Stat/ECM/path/gauss_${sub}_ecm_pos.v; done 
infiles_CTRL=`ls ../Group_Stat/ECM/ctrl/*.v`
infiles_PATH=`ls ../Group_Stat/ECM/path/*.v`

vROItwosample_ttest -in1 ${infiles_CTRL} -in2 ${infiles_PATH} -mask ../Data/utils/DMN_msk_3mm_bin.v -report ../Group_Stat/roiDMN_CTRL_vs_PATH.txt 

## Export mean DMN for correlations
for inData in ../Group_Stat/ECM/gauss/gauss_*_ecm_pos_4FSL_pos_scaled.nii.gz
do
dirName=$(dirname ${inData})
fileName=$(basename ${inData})
fileName="${fileName%.*.*}"
echo ${dirName}/${fileName}
fsl5.0-fslmeants -w -i ${dirName}/${fileName} -o ${dirName}/${fileName}_w.txt -m ${DMN_msk}  
fsl5.0-fslmeants  -i ${dirName}/${fileName} -o ${dirName}/${fileName}.txt -m ${DMN_msk}  
done


#   # 2nd-level analysis: group statistics - voxel-wise

Alpha="0.05"
if [ ! -e ../Group_Stat ] ; then mkdir ../Group_Stat; fi
if [ ! -e ../Group_Stat/ECM/ ] ; then mkdir ../Group_Stat/ECM/ ; fi
if [ ! -e ../Group_Stat/ECM/gauss ] ; then mkdir ../Group_Stat/ECM/gauss ; fi
if [ ! -e ../Group_Stat/ECM/ctrl ] ; then mkdir ../Group_Stat/ECM/ctrl ; fi
if [ ! -e ../Group_Stat/ECM/path ] ; then mkdir ../Group_Stat/ECM/path ; fi

mv ../Data/fMRI/A000?????/A000?????_ecm_pos.v ../Group_Stat/ECM/gauss/
sed -i '1d' ../Group_Stat/ECM/gauss/*
var1="V-data 2 {"
var2="	history: {"
sed -i "1s/.*/$var1/" ../Group_Stat/ECM/gauss/*
sed -i "2s/.*/$var2/" ../Group_Stat/ECM/gauss/*
cd ../Group_Stat/ECM/gauss/
vgaussianize -in *
cd -

for sub in ${CTRL_subs}; do mv  ../Group_Stat/ECM/gauss/gauss_${sub}_ecm_pos.v ../Group_Stat/ECM/ctrl/gauss_${sub}_ecm_pos.v; done 
for sub in ${PATH_subs}; do mv  ../Group_Stat/ECM/gauss/gauss_${sub}_ecm_pos.v ../Group_Stat/ECM/path/gauss_${sub}_ecm_pos.v; done 

Thresholds="2.3"
for Thresh in ${Thresholds}
do
    analyses='pos'  
    for ANALYSIS in ${analyses}
    do
      if [ ! -e ../Group_Stat/ECM/${ANALYSIS}/ ] ; then mkdir ../Group_Stat/ECM/${ANALYSIS} ; fi
      infiles_CTRL=`ls ../Group_Stat/ECM/ctrl/*.v`
      infiles_PATH=`ls ../Group_Stat/ECM/path/*.v`
      
      # # CALC GROUP AVERAGES: 
      vave -in $infiles_CTRL -out ../Group_Stat/ECM/${ANALYSIS}/ECM_average_CTRL.v
      vave -in $infiles_PATH -out ../Group_Stat/ECM/${ANALYSIS}/ECM_average_PATH.v
      
      # # DO PAIRED TTESTS (assuming conditions' averages as repeated measures):         
      vtwosample_ttest -in1 $infiles_CTRL -in2 $infiles_PATH -out ../Group_Stat/ECM/${ANALYSIS}/ECM_twosample_ttest_CTRL_vs_PATH.v 
      
      # PERFORM MULTIPLE CORRECTION & FIND SIGNIFICANT BLOBS
      contrasts="CTRL_vs_PATH"
      for CONTRAST in ${contrasts}
      do
      eval curCONTRAST=\${infiles_${CONTRAST}}
      vimagemask -in ../Group_Stat/ECM/${ANALYSIS}/ECM_twosample_ttest_${CONTRAST}.v -mask ../Data/utils/ICBM_GM_MNI_3mm.v -out ../Group_Stat/ECM/${ANALYSIS}/ECM_twosample_ttest_${CONTRAST}_maskave.v -min 1000 -max 100000 -type inside
      vmulticomp -in ../Group_Stat/ECM/${ANALYSIS}/ECM_twosample_ttest_${CONTRAST}_maskave.v -z ${Thresh} -fwhm ${total_smoothness} -symmetry true -p ${Alpha} -out ../Group_Stat/ECM/${ANALYSIS}/ECM_twosample_ttest_${CONTRAST}_${Thresh}_${Alpha}_symm.v -iter 5000
      vdomulticomp -in ../Group_Stat/ECM/${ANALYSIS}/ECM_twosample_ttest_${CONTRAST}_maskave.v -out ../Group_Stat/ECM/${ANALYSIS}/multicomp_ECM_${CONTRAST}_${Thresh}_${Alpha}.v -file ../Group_Stat/ECM/${ANALYSIS}/ECM_twosample_ttest_${CONTRAST}_${Thresh}_${Alpha}_symm.v
      vblobsize -in ../Group_Stat/ECM/${ANALYSIS}/multicomp_ECM_${CONTRAST}_${Thresh}_${Alpha}.v -out ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_VOX.v -system voxel -pos ${Thresh} -neg -${Thresh} -minsize 1 -report ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_VOX.txt 
      vblobsize -in ../Group_Stat/ECM/${ANALYSIS}/multicomp_ECM_${CONTRAST}_${Thresh}_${Alpha}.v -out ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_MNI.v -system MNI   -pos ${Thresh} -neg -${Thresh} -minsize 1 -report ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_MNI.txt 
      done
    done
done

contrasts="effect_of_age_on_ctrl effect_of_age_on_path"
Thresholds="2.3"
for Thresh in ${Thresholds}
do
    analyses='pos'  
    for ANALYSIS in ${analyses}
    do
      for CONTRAST in ${contrasts}
      do 
       if [ ${CONTRAST} == "effect_of_age_on_ctrl" ] ; then infiles=${infiles_CTRL}; fi
       if [ ${CONTRAST} == "effect_of_age_on_path" ] ; then infiles=${infiles_PATH}; fi
    
    v2ndlevel -in ${infiles} -out ../Group_Stat/ECM/pos/beta_${CONTRAST}.v -design designs/des_${CONTRAST}.txt
    vgetcontrast -in ../Group_Stat/ECM/pos/beta_${CONTRAST}.v -out ../Group_Stat/ECM/pos/zmap_${CONTRAST}.v -con 1 0  -type zmap 
    
      # PERFORM MULTIPLE CORRECTION & FIND SIGNIFICANT BLOBS
      eval curCONTRAST=\${infiles_${CONTRAST}}
      vimagemask -in ../Group_Stat/ECM/pos/zmap_${CONTRAST}.v -mask ../Data/utils/ICBM_GM_MNI_3mm.v -out ../Group_Stat/ECM/${ANALYSIS}/zmap_${CONTRAST}_maskave.v -min 1000 -max 100000 -type inside
      vmulticomp -in ../Group_Stat/ECM/${ANALYSIS}/zmap_${CONTRAST}_maskave.v -z ${Thresh} -fwhm ${total_smoothness} -symmetry true -p ${Alpha} -out ../Group_Stat/ECM/${ANALYSIS}/zmap_${CONTRAST}_${Thresh}_${Alpha}_symm.v -iter 1000
      vdomulticomp -in ../Group_Stat/ECM/${ANALYSIS}/zmap_${CONTRAST}_maskave.v -out ../Group_Stat/ECM/${ANALYSIS}/multicomp_ECM_${CONTRAST}_${Thresh}_${Alpha}.v -file ../Group_Stat/ECM/${ANALYSIS}/zmap_${CONTRAST}_${Thresh}_${Alpha}_symm.v
      vblobsize -in ../Group_Stat/ECM/${ANALYSIS}/multicomp_ECM_${CONTRAST}_${Thresh}_${Alpha}.v -out ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_VOX.v -system voxel -pos ${Thresh} -neg -${Thresh} -minsize 1 -report ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_VOX.txt 
      vblobsize -in ../Group_Stat/ECM/${ANALYSIS}/multicomp_ECM_${CONTRAST}_${Thresh}_${Alpha}.v -out ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_MNI.v -system MNI   -pos ${Thresh} -neg -${Thresh} -minsize 1 -report ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_MNI.txt 
      done
    done
done


for sub in ${CTRL_subs}; do mv  ../Group_Stat/ECM/ctrl/gauss_${sub}_ecm_pos.v ../Group_Stat/ECM/gauss/gauss_${sub}_ecm_pos.v; done 
for sub in ${PATH_subs}; do mv  ../Group_Stat/ECM/path/gauss_${sub}_ecm_pos.v ../Group_Stat/ECM/gauss/gauss_${sub}_ecm_pos.v; done 
infiles=`ls ../Group_Stat/ECM/gauss/gauss_*_ecm_pos.v`    
contrasts="effect_of_ortho_DMN_NF_DN effect_of_ortho_DMN_NF_UP"
Thresholds="2.3"
for Thresh in ${Thresholds}
do
    analyses='pos'  
    for ANALYSIS in ${analyses}
    do
      for CONTRAST in ${contrasts}
      do 
    v2ndlevel -in ${infiles} -out ../Group_Stat/ECM/pos/beta_${CONTRAST}.v -design designs/des_${CONTRAST}.txt
    vgetcontrast -in ../Group_Stat/ECM/pos/beta_${CONTRAST}.v -out ../Group_Stat/ECM/pos/zmap_${CONTRAST}.v -con 1 0  -type zmap 
    
      # PERFORM MULTIPLE CORRECTION & FIND SIGNIFICANT BLOBS
      eval curCONTRAST=\${infiles_${CONTRAST}}
      vimagemask -in ../Group_Stat/ECM/pos/zmap_${CONTRAST}.v -mask ../Data/utils/ICBM_GM_MNI_3mm.v -out ../Group_Stat/ECM/${ANALYSIS}/zmap_${CONTRAST}_maskave.v -min 1000 -max 100000 -type inside
      vmulticomp -in ../Group_Stat/ECM/${ANALYSIS}/zmap_${CONTRAST}_maskave.v -z ${Thresh} -fwhm ${total_smoothness} -symmetry true -p ${Alpha} -out ../Group_Stat/ECM/${ANALYSIS}/zmap_${CONTRAST}_${Thresh}_${Alpha}_symm.v -iter 1000
      vdomulticomp -in ../Group_Stat/ECM/${ANALYSIS}/zmap_${CONTRAST}_maskave.v -out ../Group_Stat/ECM/${ANALYSIS}/multicomp_ECM_${CONTRAST}_${Thresh}_${Alpha}.v -file ../Group_Stat/ECM/${ANALYSIS}/zmap_${CONTRAST}_${Thresh}_${Alpha}_symm.v
      vblobsize -in ../Group_Stat/ECM/${ANALYSIS}/multicomp_ECM_${CONTRAST}_${Thresh}_${Alpha}.v -out ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_VOX.v -system voxel -pos ${Thresh} -neg -${Thresh} -minsize 1 -report ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_VOX.txt 
      vblobsize -in ../Group_Stat/ECM/${ANALYSIS}/multicomp_ECM_${CONTRAST}_${Thresh}_${Alpha}.v -out ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_MNI.v -system MNI   -pos ${Thresh} -neg -${Thresh} -minsize 1 -report ../Group_Stat/ECM/${ANALYSIS}/ECM_${CONTRAST}_${Thresh}_${Alpha}_blobs_MNI.txt 
      done
    done
done

