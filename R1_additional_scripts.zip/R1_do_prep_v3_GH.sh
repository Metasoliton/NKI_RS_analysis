#!/bin/bash

# PART 1: Preparatory
echo making new directories to organize files to be created during preprocessing
if [ ! -e ../Data/tmp ] ; then mkdir ../Data/tmp/; fi ;		
if [ ! -e ../Data/fMRI ] ; then mkdir ../Data/fMRI ; fi ;	if [ ! -e ../Data/sMRI ] ; then mkdir ../Data/sMRI ; fi

EPI_data="../Data/swusub_3mm/swusub-${1}_3mm.nii.gz"

echo converting data from participant  ${1} into LIPSIA format; 

mkdir ../Data/fMRI/${1}/;  vvinidi -in ${EPI_data} -out ../Data/tmp/tempFile_A.v  -tr ${3}  -repn float     ; 
vattredit -in ../Data/tmp/tempFile_A.v -out ../Data/tmp/tempFile_B.v -name "ca"     -value "30 30 37.3333321" 
vattredit -in ../Data/tmp/tempFile_B.v -out ../Data/tmp/tempFile_C.v -name "cp"     -value "30 39 37.3333321" 
vattredit -in ../Data/tmp/tempFile_C.v -out ../Data/tmp/tmp0.v       -name "extent" -value "140 175 131"
rm ../Data/tmp/tempFile_*.v  

# # PART 2: Preprocessing
echo registering the functional data to the mni data participant ${1} ;
valign3d -in ../Data/tmp/tmp0.v -ref ../Data/utils/ICBM_BRAIN_MNI_3mm.v -trans ../Data/tmp/trans.nii -prealign  true -transform VersorRigid

echo transforming the functional data to the mni data participant ${1};
vdotrans3d -in ../Data/tmp/tmp0.v -ref ../Data/utils/ICBM_BRAIN_MNI_3mm.v -trans ../Data/tmp/trans.nii -out ../Data/tmp/tmp1.v -res 3 -fmri

echo preprocessing functional data from participant ${1} ; vpreprocess -in ../Data/tmp/tmp1.v -out ../Data/fMRI/${1}/p${1}.v -fwhm ${2} -low 0 -high 90    # -low 10 could also be tried as suggested in LIPSIA's "Shell Scripts"

rm ../Data/tmp/*
