clear; load DMN_NF.mat ; load IDs.mat 
CTRL=ClinicalStatus ; PATHO=(CTRL-1)*(-1) ; % prepare dummy variables


% Organize subjects alphabetically according to subject ID, for compatibility with CONN/FSL ordering/numbering
for i=1:length(ID); id{i}=ID(i,:); end
[s ord]=sort(id);

CTRL_ord=CTRL(ord);
PATHO_ord=PATHO(ord);
age_ord=age(ord);
ID_ord=ID(ord,:);
DMN_NF_UP_learning_ord=DMN_NF_UP_learning(ord);
DMN_NF_UP_learning_ord=DMN_NF_UP_learning(ord);



%% Pathology
    % To investigate differences in DMN connectivity at baseline between the two groups
    fid=fopen('design_effect_of_pathology.mat','w');
    fprintf(fid, '%s \r', '/NumWaves 2');
    fprintf(fid, '%s \r', '/NumPoints 136');
    fprintf(fid, '%s \r', '/Matrix');
    for s=1:136; 
        fprintf(fid, '%s \r', [num2str(CTRL_ord(s)) ' ' num2str(PATHO_ord(s))]);
    end
    fid=fopen('design_effect_of_pathology.con','w');
    fprintf(fid, '%s \r', '/NumWaves 2');    
    fprintf(fid, '%s \r', '/ContrastName1  "CTRL>PATHO"');
    fprintf(fid, '%s \r', '/ContrastName2  "PATHO>CTRL"');
    fprintf(fid, '%s \r', '/NumContrasts  2');
    fprintf(fid, '%s \r', '/Matrix');
    fprintf(fid, '%s \r', '1 -1');
    fprintf(fid, '%s \r', '-1 1');    
    fclose('all')
    

%% Age
    % To investigate differences in DMN connectivity at baseline across age in controls
    fid=fopen('design_effect_of_age_in_controls.mat','w');
    fprintf(fid, '%s \r', '/NumWaves 1');
    fprintf(fid, '%s \r', '/NumPoints 62');
    fprintf(fid, '%s \r', '/Matrix');
    for s=1:136; 
        if CTRL_ord(s)==1; fprintf(fid, '%s \r', [num2str(age_ord(s)-mean(age_ord(CTRL_ord==1)))]); end
    end
    fid=fopen('design_effect_of_age_in_controls.con','w');
    fprintf(fid, '%s \r', '/NumWaves 1');    
    fprintf(fid, '%s \r', '/ContrastName1  "AGE_CTRL(+)"');
    fprintf(fid, '%s \r', '/ContrastName2  "AGE_CTRL(-)"');
    fprintf(fid, '%s \r', '/NumContrasts  2');
    fprintf(fid, '%s \r', '/Matrix');
    fprintf(fid, '%s \r', '1');
    fprintf(fid, '%s \r', '-1');    
    fclose('all')

    
    % To investigate differences in DMN connectivity at baseline across age in patients
    fid=fopen('design_effect_of_age_in_patients.mat','w');
    fprintf(fid, '%s \r', '/NumWaves 1');
    fprintf(fid, '%s \r', '/NumPoints 74');
    fprintf(fid, '%s \r', '/Matrix');
        for s=1:136; 
        if PATHO_ord(s)==1; fprintf(fid, '%s \r', [num2str(age_ord(s)-mean(age_ord(PATHO_ord==1)))]); end
    end
    fid=fopen('design_effect_of_age_in_patients.con','w');
    fprintf(fid, '%s \r', '/NumWaves 1');    
    fprintf(fid, '%s \r', '/ContrastName1  "AGE_PATHO(+)"');
    fprintf(fid, '%s \r', '/ContrastName2  "AGE_PATHO(-)"');
    fprintf(fid, '%s \r', '/NumContrasts  2');
    fprintf(fid, '%s \r', '/Matrix');
    fprintf(fid, '%s \r', '1');
    fprintf(fid, '%s \r', '-1');    
    fclose('all')

% Learning

% To assess what differences in DMN connectivity at baseline predict DMN_NF_UP_learning independently of Age and Pathological History
    oDes = spm_orth([ClinicalStatus zscore(age') zscore(DMN_NF_UP_learning)]);   % orthogonalize DMN_NF_UP_learning to Clinical Status and Age (requires the SPM toolbox to be installed)
    ortho_DMN_NF_UP_learning = oDes(:,3);
    corr([ortho_DMN_NF_UP_learning DMN_NF_UP_learning ClinicalStatus age'])                          % confirm orthogonal data correlate with original and not with covariates
    fid=fopen('design_effect_on_ortho_DMN_NF_UP_learning.mat','w');
    fprintf(fid, '%s \r', '/NumWaves 1');
    fprintf(fid, '%s \r', '/NumPoints 136');
    fprintf(fid, '%s \r', '/Matrix');
    ortho_DMN_NF_UP_learning_ord=ortho_DMN_NF_UP_learning(ord);
    for s=1:136; 
        fprintf(fid, '%s \r', [num2str(ortho_DMN_NF_UP_learning_ord(s)-mean(ortho_DMN_NF_UP_learning_ord))]);
    end
    fid=fopen('design_effect_on_ortho_DMN_NF_UP_learning.con','w');
    fprintf(fid, '%s \r', '/NumWaves 1');    
    fprintf(fid, '%s \r', '/ContrastName1  "ortho_DMN_NF_UP_learning(+)"');
    fprintf(fid, '%s \r', '/ContrastName2  "ortho_DMN_NF_UP_learning(-)"');
    fprintf(fid, '%s \r', '/NumContrasts  2');
    fprintf(fid, '%s \r', '/Matrix');
    fprintf(fid, '%s \r', '1');
    fprintf(fid, '%s \r', '-1');    
    fclose('all')


% To assess what differences in DMN connectivity at baseline predict DMN_NF_DN_learning independently of Age and Pathological History
    oDes = spm_orth([ClinicalStatus zscore(age') zscore(DMN_NF_DN_learning)]);   % orthogonalize DMN_NF_UP_learning to Clinical Status and Age
    ortho_DMN_NF_DN_learning = oDes(:,3);
    corr([ortho_DMN_NF_DN_learning DMN_NF_DN_learning ClinicalStatus age'])                          % confirm orthogonal data correlate with original and not with covariates
    
    fid=fopen('design_effect_on_ortho_DMN_NF_DN_learning.mat','w');
    fprintf(fid, '%s \r', '/NumWaves 1');
    fprintf(fid, '%s \r', '/NumPoints 136');
    fprintf(fid, '%s \r', '/Matrix');
    ortho_DMN_NF_DN_learning_ord=ortho_DMN_NF_DN_learning(ord);
    for s=1:136; 
        fprintf(fid, '%s \r', [num2str(ortho_DMN_NF_DN_learning_ord(s)-ortho_DMN_NF_DN_learning_ord)]);
    end
    fid=fopen('design_effect_on_ortho_DMN_NF_DN_learning.con','w');
    fprintf(fid, '%s \r', '/NumWaves 1');    
    fprintf(fid, '%s \r', '/ContrastName1  "ortho_DMN_NF_DN_learning(+)"');
    fprintf(fid, '%s \r', '/ContrastName2  "ortho_DMN_NF_DN_learning(-)"');
    fprintf(fid, '%s \r', '/NumContrasts  2');
    fprintf(fid, '%s \r', '/Matrix');
    fprintf(fid, '%s \r', '1');
    fprintf(fid, '%s \r', '-1');    
    fclose('all')