#!/bin/bash

movelist=../Data/imports/sub-${1}/ses-NFB3/func/rp_sub-${1}_ses-NFB3_task-DMNTRACKINGTRAIN_bold.txt
vcovariates -in ${movelist}   -out ../Data/fMRI/${1}/mov${1}.v      -tr ${2}       
vresiduals  -in ../Data/fMRI/${1}/p${1}.v  -design ../Data/fMRI/${1}/mov${1}.v -out ../Data/fMRI/${1}/pm${1}.v    -min 4000

analyses='pos'  
for ANALYSIS in ${analyses}
do
    vecm -in ../Data/fMRI/${1}/pm${1}.v  -mask ../Data/utils/ICBM_GM_MNI_3mm.v  -out ../Data/fMRI/${1}/${1}_ecm_${ANALYSIS}.v -first 6 -length 183 -j 8 -type ${ANALYSIS} 
done

sed -i '4d' ../Data/fMRI/${1}/${1}_ecm_${ANALYSIS}.v 












