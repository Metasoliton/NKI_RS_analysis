#!/bin/bash

for sub in ${inVPs}
do

echo CURRENT SUBJECT  ${sub}

inDataT1="./*/sub-${sub}_ses-NFB3_T1w.nii.gz"
inDataEPI="./*/usub-${sub}_ses-NFB3_task-DMNTRACKINGTRAIN_bold.nii"

T1_fileName=$(basename ${inDataT1})
T1_dirName=$(dirname ${inDataT1})

cp ${T1_dirName}/${T1_fileName} ${T1_dirName}/tmp${T1_fileName}

fslmaths ${T1_dirName}/c1${T1_fileName}     -thr 0 ${T1_dirName}/c1${T1_fileName}_bin
fslmaths ${T1_dirName}/c2${T1_fileName}     -thr 0 ${T1_dirName}/c2${T1_fileName}_bin
fslmaths ${T1_dirName}/c1${T1_fileName}_bin -add ${T1_dirName}/c2${T1_fileName}_bin  ${T1_dirName}/tmpc0${T1_fileName}
fslmaths ${T1_dirName}/tmpc0${T1_fileName}  -bin ${T1_dirName}/c0${T1_fileName}_bin
fslmaths ${T1_dirName}/tmp${T1_fileName}    -mul ${T1_dirName}/c0${T1_fileName}_bin  ${T1_dirName}/brain.nii.gz
rm ${T1_dirName}/tmp* ${T1_dirName}/*bin*

nice bash SyGN_normalize_RocklandTest.sh ${T1_dirName}/brain.nii.gz ${inDataEPI} "Quick"

done